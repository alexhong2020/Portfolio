HELLO!

Welcome to Checkers. Weed out the instagram fakes with this tool. 

1. Go to instagram.com and request a data download in .json format. You will need followers and following folders.
2. Use an online converter such as https://konklone.io/json/ to convert to .csv file
3. Open .csv file and copy column with usernames
4. Upload to corresponding .txt file in this class
5. Hit Run in checkers.py to see who unfollowed you!

- main.py, followers.txt, following.txt are main functional classes. Others are for test beta purposes.
- Mon 06.27.22: Added checkers.md and refactored checkers.py to NOT require you to enter input files (autopickup files).


---
With <3, alex hong.